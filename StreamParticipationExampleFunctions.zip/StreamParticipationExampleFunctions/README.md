# Stream Participation Example Functions

This is a collection of example functions to be used and give inspiration for
other events

Obviously, if you don't like some events, just remove them


```
Uses AESTD by Aeldrion
https://www.github.com/Aeldrion/AESTD
https://www.twitter.com/Aeldrion
```
